#!/usr/bin/env python3
"""
CamperRouter - Flask Backend API Server
Handles all router operations, modem control, and data tracking
"""

from flask import Flask, jsonify, request
from flask_cors import CORS
import sqlite3
import json
import os
import subprocess
from datetime import datetime
import threading
import time

from database import init_db, get_db
from modem import ModemManager
from network import NetworkManager
from stats import StatsCollector
from config import Config

app = Flask(__name__)
CORS(app)

# Initialize database
init_db(app)

# Initialize managers
modem_mgr = ModemManager()
network_mgr = NetworkManager()
stats_collector = StatsCollector()

# Start background stats collection
def start_stats_thread():
    def collect():
        while True:
            stats_collector.collect_stats()
            time.sleep(5)
    thread = threading.Thread(target=collect, daemon=True)
    thread.start()

start_stats_thread()

# ==================== DASHBOARD ====================

@app.route('/api/stats', methods=['GET'])
def get_stats():
    """Get current statistics: GB used, upload/download speeds"""
    stats = stats_collector.get_current_stats()
    return jsonify(stats)

@app.route('/api/sims', methods=['GET'])
def get_sims():
    """Detect connected SIM cards"""
    sims = modem_mgr.get_sims()
    return jsonify({'sims': sims})

@app.route('/api/signal', methods=['GET'])
def get_signal():
    """Get signal strength for all SIMs"""
    signals = modem_mgr.get_signal_strength()
    return jsonify(signals)

@app.route('/api/time', methods=['GET'])
def get_time():
    """Get current time and date"""
    now = datetime.now()
    return jsonify({
        'time': now.strftime('%H:%M'),
        'date': now.strftime('%d/%m/%Y'),
        'timestamp': now.isoformat()
    })

# ==================== CONNECTED DEVICES ====================

@app.route('/api/devices', methods=['GET'])
def get_devices():
    """Get list of connected devices with bandwidth info"""
    devices = network_mgr.get_connected_devices()
    return jsonify({'devices': devices})

@app.route('/api/devices/<device_id>/block', methods=['POST'])
def block_device(device_id):
    """Block a device from internet access"""
    network_mgr.block_device(device_id)
    return jsonify({'status': 'blocked', 'device': device_id})

@app.route('/api/devices/<device_id>/allow', methods=['POST'])
def allow_device(device_id):
    """Allow a device to access internet"""
    network_mgr.allow_device(device_id)
    return jsonify({'status': 'allowed', 'device': device_id})

@app.route('/api/devices/<device_id>/bandwidth', methods=['GET'])
def get_device_bandwidth(device_id):
    """Get bandwidth usage for specific device"""
    bandwidth = network_mgr.get_device_bandwidth(device_id)
    return jsonify(bandwidth)

# ==================== SPEED TEST ====================

@app.route('/api/speedtest/run', methods=['POST'])
def run_speedtest():
    """Run speed test in background"""
    def run():
        result = stats_collector.run_speedtest()
        # Save to database
        db = get_db()
        db.execute(
            'INSERT INTO speedtests (upload, download, ping, timestamp) VALUES (?, ?, ?, ?)',
            (result['upload'], result['download'], result['ping'], datetime.now().isoformat())
        )
        db.commit()
    
    # Run in background thread
    thread = threading.Thread(target=run, daemon=True)
    thread.start()
    
    return jsonify({'status': 'running', 'message': 'Speed test started'})

@app.route('/api/speedtest/history', methods=['GET'])
def get_speedtest_history():
    """Get speed test history"""
    db = get_db()
    tests = db.execute('SELECT * FROM speedtests ORDER BY timestamp DESC LIMIT 20').fetchall()
    return jsonify({
        'tests': [dict(t) for t in tests]
    })

@app.route('/api/speedtest/current', methods=['GET'])
def get_current_speedtest():
    """Get latest speed test result"""
    db = get_db()
    test = db.execute('SELECT * FROM speedtests ORDER BY timestamp DESC LIMIT 1').fetchone()
    if test:
        return jsonify(dict(test))
    return jsonify({'error': 'No speedtest data'}, 404)

# ==================== STATISTICS ====================

@app.route('/api/statistics/daily', methods=['GET'])
def get_daily_stats():
    """Get daily usage breakdown"""
    stats = stats_collector.get_daily_stats()
    return jsonify(stats)

@app.route('/api/statistics/weekly', methods=['GET'])
def get_weekly_stats():
    """Get weekly usage breakdown"""
    stats = stats_collector.get_weekly_stats()
    return jsonify(stats)

@app.route('/api/statistics/monthly', methods=['GET'])
def get_monthly_stats():
    """Get monthly usage breakdown"""
    stats = stats_collector.get_monthly_stats()
    return jsonify(stats)

# ==================== SETTINGS ====================

@app.route('/api/wifi', methods=['GET'])
def get_wifi_config():
    """Get WiFi configuration"""
    config = network_mgr.get_wifi_config()
    return jsonify(config)

@app.route('/api/wifi', methods=['POST'])
def set_wifi_config():
    """Update WiFi configuration"""
    data = request.json
    network_mgr.set_wifi_config(data)
    return jsonify({'status': 'updated'})

@app.route('/api/brightness', methods=['GET'])
def get_brightness():
    """Get screen brightness"""
    brightness = Config.get('brightness', 100)
    return jsonify({'brightness': brightness})

@app.route('/api/brightness', methods=['POST'])
def set_brightness():
    """Set screen brightness"""
    data = request.json
    Config.set('brightness', data['brightness'])
    return jsonify({'brightness': data['brightness']})

@app.route('/api/lan', methods=['GET'])
def get_lan_config():
    """Get LAN configuration"""
    config = network_mgr.get_lan_config()
    return jsonify(config)

@app.route('/api/lan', methods=['POST'])
def set_lan_config():
    """Update LAN configuration"""
    data = request.json
    network_mgr.set_lan_config(data)
    return jsonify({'status': 'updated'})

@app.route('/api/system/info', methods=['GET'])
def get_system_info():
    """Get system information"""
    info = stats_collector.get_system_info()
    return jsonify(info)

# ==================== NOTIFICATIONS ====================

@app.route('/api/notifications', methods=['GET'])
def get_notifications():
    """Get recent notifications and alerts"""
    db = get_db()
    notifs = db.execute(
        'SELECT * FROM notifications ORDER BY timestamp DESC LIMIT 50'
    ).fetchall()
    return jsonify({'notifications': [dict(n) for n in notifs]})

@app.route('/api/notifications/<notif_id>', methods=['DELETE'])
def dismiss_notification(notif_id):
    """Dismiss a notification"""
    db = get_db()
    db.execute('DELETE FROM notifications WHERE id = ?', (notif_id,))
    db.commit()
    return jsonify({'status': 'dismissed'})

# ==================== NETWORK MAP ====================

@app.route('/api/network/map', methods=['GET'])
def get_network_map():
    """Get network topology for visualization"""
    devices = network_mgr.get_connected_devices()
    map_data = {
        'router': {
            'id': 'router',
            'name': 'CamperRouter',
            'type': 'router',
            'bandwidth': stats_collector.get_current_stats()['download']
        },
        'devices': devices
    }
    return jsonify(map_data)

# ==================== QR CODE ====================

@app.route('/api/wifi/qrcode', methods=['GET'])
def get_wifi_qrcode():
    """Generate WiFi QR code"""
    import qrcode
    import io
    import base64
    
    config = network_mgr.get_wifi_config()
    qr_string = f"WIFI:T:WPA;S:{config['ssid']};P:{config['password']};;"
    
    qr = qrcode.QRCode(version=1, box_size=10, border=5)
    qr.add_data(qr_string)
    qr.make(fit=True)
    
    img = qr.make_image(fill_color="black", back_color="white")
    
    # Convert to base64
    buffered = io.BytesIO()
    img.save(buffered, format="PNG")
    img_str = base64.b64encode(buffered.getvalue()).decode()
    
    return jsonify({'qrcode': f'data:image/png;base64,{img_str}'})

# ==================== ABOUT ====================

@app.route('/api/about', methods=['GET'])
def get_about():
    """Get app information"""
    return jsonify({
        'name': 'CamperRouter',
        'version': '1.0.0',
        'author': 'Markramcraft',
        'license': 'GPL-3.0',
        'description': 'Custom Router OS for Raspberry Pi 3 with 4G/LTE support'
    })

# ==================== WEB-ONLY ENDPOINTS ====================

@app.route('/api/modem/toggle', methods=['POST'])
def toggle_modem():
    """Toggle modem on/off"""
    state = request.json.get('state')
    modem_mgr.toggle_modem(state)
    return jsonify({'status': 'toggled', 'state': state})

@app.route('/api/modem/reset', methods=['POST'])
def reset_modem():
    """Reset modem"""
    modem_mgr.reset_modem()
    return jsonify({'status': 'reset'})

@app.route('/api/modem/info', methods=['GET'])
def get_modem_info():
    """Get modem information"""
    info = modem_mgr.get_modem_info()
    return jsonify(info)

@app.route('/api/firewall', methods=['GET'])
def get_firewall():
    """Get firewall rules"""
    rules = network_mgr.get_firewall_rules()
    return jsonify({'rules': rules})

@app.route('/api/firewall', methods=['POST'])
def add_firewall_rule():
    """Add firewall rule"""
    data = request.json
    network_mgr.add_firewall_rule(data)
    return jsonify({'status': 'added'})

@app.route('/api/portforward', methods=['GET'])
def get_portforward():
    """Get port forwarding rules"""
    rules = network_mgr.get_portforward_rules()
    return jsonify({'rules': rules})

@app.route('/api/portforward', methods=['POST'])
def add_portforward():
    """Add port forwarding rule"""
    data = request.json
    network_mgr.add_portforward_rule(data)
    return jsonify({'status': 'added'})

@app.route('/api/dns', methods=['GET'])
def get_dns():
    """Get DNS configuration"""
    config = network_mgr.get_dns_config()
    return jsonify(config)

@app.route('/api/dns', methods=['POST'])
def set_dns():
    """Update DNS configuration"""
    data = request.json
    network_mgr.set_dns_config(data)
    return jsonify({'status': 'updated'})

@app.route('/api/dhcp', methods=['GET'])
def get_dhcp():
    """Get DHCP configuration"""
    config = network_mgr.get_dhcp_config()
    return jsonify(config)

@app.route('/api/dhcp', methods=['POST'])
def set_dhcp():
    """Update DHCP configuration"""
    data = request.json
    network_mgr.set_dhcp_config(data)
    return jsonify({'status': 'updated'})

@app.route('/api/logs', methods=['GET'])
def get_logs():
    """Get system logs"""
    log_type = request.args.get('type', 'system')
    logs = stats_collector.get_logs(log_type)
    return jsonify({'logs': logs})

@app.route('/api/backup', methods=['POST'])
def backup_config():
    """Backup configuration"""
    backup = network_mgr.backup_config()
    return jsonify(backup)

@app.route('/api/restore', methods=['POST'])
def restore_config():
    """Restore configuration from backup"""
    data = request.json
    network_mgr.restore_config(data)
    return jsonify({'status': 'restored'})

# ==================== HEALTH CHECK ====================

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'ok',
        'timestamp': datetime.now().isoformat()
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)
