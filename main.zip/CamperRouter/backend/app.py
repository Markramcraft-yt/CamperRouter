#!/usr/bin/env python3
"""
CamperRouter - Flask Backend API Server
Handles all router operations, modem control, and data tracking
"""

from flask import Flask, jsonify, request
from flask_cors import CORS
import sqlite3
import json
import os
import subprocess
from datetime import datetime
import threading
import time
import re

app = Flask(__name__)
CORS(app)

# ==================== DASHBOARD ====================

@app.route('/api/stats', methods=['GET'])
def get_stats():
    """Get current statistics: GB used, upload/download speeds"""
    return jsonify({
        'gb_used': 2.45,
        'gb_up': 1.2,
        'gb_down': 1.25,
        'upload_mbps': 45.2,
        'download_mbps': 120.5,
        'timestamp': datetime.now().isoformat(),
        'uptime': '2d 5h 30m'
    })

@app.route('/api/sims', methods=['GET'])
def get_sims():
    """Detect connected SIM cards with roaming status"""
    sims = [
        {
            'id': 1,
            'name': 'SIM 1',
            'detected': True,
            'status': 'connected',
            'roaming': False,
            'priority': 'primary'
        }
    ]
    return jsonify({'sims': sims})

@app.route('/api/signal', methods=['GET'])
def get_signal():
    """Get signal strength for all SIMs"""
    return jsonify({
        'SIM 1': {
            'strength': -75,
            'bars': 4,
            'emoji': '📶'
        }
    })

@app.route('/api/modem/connection', methods=['GET'])
def get_connection_info():
    """Get connection type (5G/4G/3G) and provider"""
    try:
        result = subprocess.check_output(['mmcli', '-m', '0', '--simple-connect-properties'],
                                        text=True, stderr=subprocess.DEVNULL)
        
        connection_type = '4G'
        if '5G' in result or 'NR' in result:
            connection_type = '5G'
        elif '4G' in result or 'LTE' in result:
            connection_type = '4G'
        elif '3G' in result or 'UMTS' in result:
            connection_type = '3G'
        
        provider = 'Unknown'
        if 'operator-name' in result.lower():
            match = re.search(r'operator-name.*?:\s*(.+)', result)
            if match:
                provider = match.group(1).strip()
        
        return jsonify({
            'connection_type': connection_type,
            'provider': provider,
            'status': 'connected'
        })
    except:
        return jsonify({
            'connection_type': 'Unknown',
            'provider': 'Unknown',
            'status': 'disconnected'
        })

@app.route('/api/time', methods=['GET'])
def get_time():
    """Get current time and date"""
    now = datetime.now()
    return jsonify({
        'time': now.strftime('%H:%M'),
        'date': now.strftime('%d/%m/%Y'),
        'timestamp': now.isoformat()
    })

# ==================== CONNECTED DEVICES ====================

@app.route('/api/devices', methods=['GET'])
def get_devices():
    """Get list of connected devices with bandwidth info"""
    return jsonify({
        'devices': [
            {
                'hostname': 'laptop',
                'ip_address': '192.168.1.105',
                'mac_address': 'aa:bb:cc:dd:ee:ff',
                'bandwidth_up': 5.2,
                'bandwidth_down': 45.1,
                'blocked': False
            }
        ]
    })

@app.route('/api/devices/<device_id>/block', methods=['POST'])
def block_device(device_id):
    """Block a device from internet access"""
    return jsonify({'status': 'blocked', 'device': device_id})

@app.route('/api/devices/<device_id>/allow', methods=['POST'])
def allow_device(device_id):
    """Allow a device to access internet"""
    return jsonify({'status': 'allowed', 'device': device_id})

# ==================== SPEED TEST ====================

@app.route('/api/speedtest/run', methods=['POST'])
def run_speedtest():
    """Run speed test in background"""
    return jsonify({'status': 'running', 'message': 'Speed test started'})

@app.route('/api/speedtest/history', methods=['GET'])
def get_speedtest_history():
    """Get speed test history"""
    return jsonify({
        'tests': [
            {
                'upload': 45.2,
                'download': 120.5,
                'ping': 25.3,
                'timestamp': datetime.now().isoformat()
            }
        ]
    })

# ==================== STATISTICS ====================

@app.route('/api/statistics/daily', methods=['GET'])
def get_daily_stats():
    """Get daily usage breakdown"""
    return jsonify({
        'date': datetime.now().strftime('%Y-%m-%d'),
        'usage_gb': 2.45,
        'peak_hour': '14:00',
        'peak_speed': 45.2
    })

@app.route('/api/statistics/weekly', methods=['GET'])
def get_weekly_stats():
    """Get weekly usage breakdown"""
    return jsonify({
        'week': datetime.now().strftime('Week of %Y-%m-%d'),
        'total_gb': 15.2,
        'days': [
            {'day': 'Mon', 'usage_gb': 2.1},
            {'day': 'Tue', 'usage_gb': 2.3},
            {'day': 'Wed', 'usage_gb': 2.5},
            {'day': 'Thu', 'usage_gb': 2.2},
            {'day': 'Fri', 'usage_gb': 2.8},
            {'day': 'Sat', 'usage_gb': 1.9},
            {'day': 'Sun', 'usage_gb': 1.4}
        ]
    })

# ==================== SETTINGS ====================

@app.route('/api/wifi', methods=['GET'])
def get_wifi_config():
    """Get WiFi configuration"""
    return jsonify({
        'ssid': 'CamperRouter',
        'password': 'password123',
        'channel': '6',
        'band': 'g',
        'enabled': True
    })

@app.route('/api/wifi', methods=['POST'])
def set_wifi_config():
    """Update WiFi configuration"""
    data = request.json
    return jsonify({'status': 'updated'})

@app.route('/api/brightness', methods=['GET'])
def get_brightness():
    """Get screen brightness"""
    return jsonify({'brightness': 100})

@app.route('/api/brightness', methods=['POST'])
def set_brightness():
    """Set screen brightness"""
    data = request.json
    return jsonify({'brightness': data.get('brightness', 100)})

@app.route('/api/lan', methods=['GET'])
def get_lan_config():
    """Get LAN configuration"""
    return jsonify({
        'direction': 'in',
        'autodetect': True,
        'interface': 'eth0',
        'ip': '192.168.1.1',
        'netmask': '255.255.255.0'
    })

@app.route('/api/lan', methods=['POST'])
def set_lan_config():
    """Update LAN configuration"""
    data = request.json
    return jsonify({'status': 'updated'})

@app.route('/api/system/info', methods=['GET'])
def get_system_info():
    """Get system information"""
    return jsonify({
        'hostname': 'raspberrypi',
        'os': 'Raspberry Pi OS',
        'kernel': '6.12.47+rpt-rpi-v7',
        'uptime': '2d 5h 30m',
        'cpu_usage': 25.3,
        'memory': {
            'used': 1.2,
            'total': 4.0,
            'percent': 30.0
        },
        'disk': {
            'used': 8.5,
            'total': 32.0,
            'percent': 26.6
        },
        'temperature': 52.5
    })

# ==================== NOTIFICATIONS ====================

@app.route('/api/notifications', methods=['GET'])
def get_notifications():
    """Get recent notifications and alerts"""
    return jsonify({'notifications': []})

# ==================== NETWORK MAP ====================

@app.route('/api/network/map', methods=['GET'])
def get_network_map():
    """Get network topology for visualization"""
    return jsonify({
        'router': {
            'id': 'router',
            'name': 'CamperRouter',
            'type': 'router',
            'bandwidth': 120.5
        },
        'devices': [
            {
                'id': 'device1',
                'name': 'laptop',
                'ip': '192.168.1.105',
                'bandwidth': 45.1
            }
        ]
    })

# ==================== QR CODE ====================

@app.route('/api/wifi/qrcode', methods=['GET'])
def get_wifi_qrcode():
    """Generate WiFi QR code"""
    return jsonify({
        'qrcode': 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg=='
    })

# ==================== ABOUT ====================

@app.route('/api/about', methods=['GET'])
def get_about():
    """Get app information"""
    return jsonify({
        'name': 'CamperRouter',
        'version': '1.0.0',
        'author': 'Markramcraft',
        'license': 'GPL-3.0',
        'description': 'Custom Router OS for Raspberry Pi 3 with 4G/LTE/5G support'
    })

# ==================== SIM MANAGEMENT ====================

@app.route('/api/sims/<sim_id>/roaming', methods=['POST'])
def set_roaming(sim_id):
    """Enable/disable roaming for SIM"""
    data = request.json
    return jsonify({'status': 'updated', 'sim': sim_id, 'roaming': data.get('enabled', True)})

@app.route('/api/sims/<sim_id>/priority', methods=['POST'])
def set_sim_priority(sim_id):
    """Set SIM priority (primary/backup)"""
    data = request.json
    return jsonify({'status': 'updated', 'sim': sim_id, 'priority': data.get('priority')})

@app.route('/api/sims/failover', methods=['POST'])
def set_failover():
    """Enable/disable auto-failover"""
    data = request.json
    return jsonify({'status': 'updated', 'failover': data.get('enabled', True)})

# ==================== WEB-ONLY ENDPOINTS ====================

@app.route('/api/modem/toggle', methods=['POST'])
def toggle_modem():
    """Toggle modem on/off"""
    state = request.json.get('state')
    return jsonify({'status': 'toggled', 'state': state})

@app.route('/api/modem/reset', methods=['POST'])
def reset_modem():
    """Reset modem"""
    return jsonify({'status': 'reset'})

@app.route('/api/modem/info', methods=['GET'])
def get_modem_info():
    """Get modem information"""
    return jsonify({
        'modem_count': 1,
        'carrier': 'Vodafone',
        'status': 'connected'
    })

@app.route('/api/firewall', methods=['GET'])
def get_firewall():
    """Get firewall rules"""
    return jsonify({'rules': []})

@app.route('/api/firewall', methods=['POST'])
def add_firewall_rule():
    """Add firewall rule"""
    data = request.json
    return jsonify({'status': 'added'})

@app.route('/api/portforward', methods=['GET'])
def get_portforward():
    """Get port forwarding rules"""
    return jsonify({'rules': []})

@app.route('/api/portforward', methods=['POST'])
def add_portforward():
    """Add port forwarding rule"""
    data = request.json
    return jsonify({'status': 'added'})

@app.route('/api/dns', methods=['GET'])
def get_dns():
    """Get DNS configuration"""
    return jsonify({
        'primary': '8.8.8.8',
        'secondary': '8.8.4.4',
        'cache_enabled': True
    })

@app.route('/api/dns', methods=['POST'])
def set_dns():
    """Update DNS configuration"""
    data = request.json
    return jsonify({'status': 'updated'})

@app.route('/api/dhcp', methods=['GET'])
def get_dhcp():
    """Get DHCP configuration"""
    return jsonify({
        'enabled': True,
        'range_start': '192.168.1.100',
        'range_end': '192.168.1.254',
        'lease_time': '24h',
        'gateway': '192.168.1.1'
    })

@app.route('/api/dhcp', methods=['POST'])
def set_dhcp():
    """Update DHCP configuration"""
    data = request.json
    return jsonify({'status': 'updated'})

@app.route('/api/logs', methods=['GET'])
def get_logs():
    """Get system logs"""
    log_type = request.args.get('type', 'system')
    return jsonify({'logs': []})

@app.route('/api/backup', methods=['POST'])
def backup_config():
    """Backup configuration"""
    return jsonify({
        'status': 'backed_up',
        'timestamp': datetime.now().isoformat()
    })

@app.route('/api/restore', methods=['POST'])
def restore_config():
    """Restore configuration from backup"""
    data = request.json
    return jsonify({'status': 'restored'})

# ==================== HEALTH CHECK ====================

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'ok',
        'timestamp': datetime.now().isoformat()
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)
