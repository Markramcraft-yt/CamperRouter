#!/usr/bin/env python3
"""
ModemManager integration for ZTE MF833V and other USB modems
Handles modem detection, SIM management, signal strength
"""

import subprocess
import re
import json
from typing import List, Dict

class ModemManager:
    def __init__(self):
        self.bus = self._init_dbus()
    
    def _init_dbus(self):
        """Initialize DBus connection to ModemManager"""
        try:
            import dbus
            return dbus.SystemBus()
        except:
            return None
    
    def get_modems(self) -> List[Dict]:
        """Get list of detected modems"""
        try:
            result = subprocess.check_output(['mmcli', '-L'], text=True)
            modems = []
            for line in result.split('\n'):
                if 'modem' in line.lower():
                    modems.append(line.strip())
            return modems
        except:
            return []
    
    def get_sims(self) -> List[Dict]:
        """Detect connected SIM cards"""
        try:
            result = subprocess.check_output(['mmcli', '-L'], text=True)
            sims = []
            modem_count = 0
            
            for line in result.split('\n'):
                if 'modem' in line.lower():
                    modem_count += 1
                    sims.append({
                        'id': modem_count,
                        'name': f'SIM {modem_count}',
                        'detected': True,
                        'status': 'connected'
                    })
            
            return sims
        except:
            return []
    
    def get_signal_strength(self) -> Dict:
        """Get signal strength for all modems"""
        signals = {}
        modems = self.get_modems()
        
        for i, modem in enumerate(modems):
            try:
                modem_num = i
                result = subprocess.check_output(
                    ['mmcli', '-m', str(modem_num), '--signal-get'],
                    text=True, stderr=subprocess.DEVNULL
                )
                
                # Parse signal strength
                if 'RSSI' in result:
                    rssi = re.search(r'RSSI.*?(\d+)', result)
                    if rssi:
                        strength = int(rssi.group(1))
                        signals[f'SIM {i+1}'] = {
                            'strength': strength,
                            'bars': self._strength_to_bars(strength),
                            'emoji': self._strength_to_emoji(strength)
                        }
            except:
                pass
        
        return signals
    
    def _strength_to_bars(self, strength: int) -> int:
        """Convert RSSI to bars (0-4)"""
        if strength == 0:
            return 0
        elif strength < -100:
            return 1
        elif strength < -85:
            return 2
        elif strength < -70:
            return 3
        else:
            return 4
    
    def _strength_to_emoji(self, strength: int) -> str:
        """Convert RSSI to emoji"""
        bars = self._strength_to_bars(strength)
        emojis = ['❌', '📶', '📶', '📶', '📶']
        return emojis[bars]
    
    def get_modem_info(self) -> Dict:
        """Get detailed modem information"""
        try:
            result = subprocess.check_output(['mmcli', '-L'], text=True)
            modems = self.get_modems()
            
            if not modems:
                return {'error': 'No modems detected'}
            
            modem_num = 0
            info_result = subprocess.check_output(
                ['mmcli', '-m', str(modem_num), '--simple-connect-properties'],
                text=True, stderr=subprocess.DEVNULL
            )
            
            # Parse carrier name
            carrier = 'Unknown'
            if 'operator-name' in info_result.lower():
                carrier_match = re.search(r'operator-name.*?:\s*(.+)', info_result)
                if carrier_match:
                    carrier = carrier_match.group(1).strip()
            
            signals = self.get_signal_strength()
            
            return {
                'modem_count': len(modems),
                'carrier': carrier,
                'signals': signals,
                'status': 'connected' if modems else 'disconnected'
            }
        except Exception as e:
            return {'error': str(e), 'status': 'error'}
    
    def toggle_modem(self, state: bool):
        """Toggle modem power on/off"""
        try:
            modem_num = 0
            if state:
                subprocess.run(['mmcli', '-m', str(modem_num), '--enable'],
                              check=True, capture_output=True)
            else:
                subprocess.run(['mmcli', '-m', str(modem_num), '--disable'],
                              check=True, capture_output=True)
            return {'status': 'toggled', 'state': state}
        except Exception as e:
            return {'error': str(e)}
    
    def reset_modem(self):
        """Reset modem"""
        try:
            modem_num = 0
            subprocess.run(['mmcli', '-m', str(modem_num), '--reset'],
                          check=True, capture_output=True)
            return {'status': 'reset'}
        except Exception as e:
            return {'error': str(e)}
    
    def get_connection_status(self) -> Dict:
        """Get connection status"""
        try:
            result = subprocess.check_output(['nmcli', 'dev', 'show'], text=True)
            
            # Check if connected to mobile network
            if 'connected' in result.lower():
                return {
                    'connected': True,
                    'type': 'mobile',
                    'status': 'connected'
                }
            return {
                'connected': False,
                'type': 'mobile',
                'status': 'disconnected'
            }
        except:
            return {
                'connected': False,
                'type': 'mobile',
                'status': 'error'
            }
