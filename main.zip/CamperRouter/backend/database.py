#!/usr/bin/env python3
"""
Database models and initialization
SQLite database for tracking stats, speed tests, notifications, etc.
"""

import sqlite3
import os
from flask import g

DATABASE = os.environ.get('DATABASE_PATH', '/var/lib/camper-router/router.db')

def get_db():
    """Get database connection"""
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db

def init_db(app):
    """Initialize database with tables"""
    os.makedirs(os.path.dirname(DATABASE), exist_ok=True)
    
    with app.app_context():
        db = get_db()
        db.executescript('''
            CREATE TABLE IF NOT EXISTS data_usage (
                id INTEGER PRIMARY KEY,
                timestamp TEXT UNIQUE,
                upload_bytes INTEGER,
                download_bytes INTEGER,
                total_bytes INTEGER
            );
            
            CREATE TABLE IF NOT EXISTS speedtests (
                id INTEGER PRIMARY KEY,
                upload REAL,
                download REAL,
                ping REAL,
                timestamp TEXT UNIQUE
            );
            
            CREATE TABLE IF NOT EXISTS devices (
                id TEXT PRIMARY KEY,
                mac_address TEXT UNIQUE,
                ip_address TEXT,
                hostname TEXT,
                first_seen TEXT,
                last_seen TEXT,
                blocked INTEGER DEFAULT 0,
                bandwidth_up REAL,
                bandwidth_down REAL
            );
            
            CREATE TABLE IF NOT EXISTS notifications (
                id INTEGER PRIMARY KEY,
                type TEXT,
                title TEXT,
                message TEXT,
                timestamp TEXT,
                read INTEGER DEFAULT 0
            );
            
            CREATE TABLE IF NOT EXISTS logs (
                id INTEGER PRIMARY KEY,
                level TEXT,
                component TEXT,
                message TEXT,
                timestamp TEXT
            );
            
            CREATE TABLE IF NOT EXISTS config (
                key TEXT PRIMARY KEY,
                value TEXT
            );
        ''')
        db.commit()

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()
