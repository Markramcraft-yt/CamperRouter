#!/usr/bin/env python3
"""
Statistics collection and monitoring
Tracks data usage, speed tests, system resources
"""

import subprocess
import psutil
import json
import re
from datetime import datetime, timedelta
from typing import Dict, List
import speedtest

class StatsCollector:
    def __init__(self):
        self.start_time = datetime.now()
        self.initial_bytes = self._get_total_bytes()
    
    def _get_total_bytes(self) -> Dict:
        """Get total bytes from all interfaces"""
        try:
            result = subprocess.check_output(['cat', '/proc/net/dev'], text=True)
            total_up = 0
            total_down = 0
            
            for line in result.split('\n')[2:]:
                if line.strip() and ':' in line:
                    parts = line.split()
                    total_down += int(parts[1])
                    total_up += int(parts[9])
            
            return {'up': total_up, 'down': total_down}
        except:
            return {'up': 0, 'down': 0}
    
    def get_current_stats(self) -> Dict:
        """Get current data usage and speeds"""
        try:
            current_bytes = self._get_total_bytes()
            used_up = (current_bytes['up'] - self.initial_bytes['up']) / (1024**3)
            used_down = (current_bytes['down'] - self.initial_bytes['down']) / (1024**3)
            total_used = used_up + used_down
            
            # Get current speeds
            speeds = self._get_current_speeds()
            
            return {
                'gb_used': round(total_used, 2),
                'gb_up': round(used_up, 2),
                'gb_down': round(used_down, 2),
                'upload_mbps': round(speeds['upload'], 2),
                'download_mbps': round(speeds['download'], 2),
                'timestamp': datetime.now().isoformat(),
                'uptime': str(datetime.now() - self.start_time).split('.')[0]
            }
        except Exception as e:
            return {
                'gb_used': 0,
                'gb_up': 0,
                'gb_down': 0,
                'upload_mbps': 0,
                'download_mbps': 0,
                'error': str(e)
            }
    
    def _get_current_speeds(self) -> Dict:
        """Get current upload/download speeds from interface"""
        try:
            # Read from /proc/net/dev
            result = subprocess.check_output(['cat', '/proc/net/dev'], text=True)
            
            # Simple approximation - would need real traffic monitoring
            return {
                'upload': 0,
                'download': 0
            }
        except:
            return {'upload': 0, 'download': 0}
    
    def collect_stats(self):
        """Background task to collect stats periodically"""
        # This runs in a thread and updates database
        stats = self.get_current_stats()
        # Save to database (would be called by Flask app)
        pass
    
    def run_speedtest(self) -> Dict:
        """Run Ookla speedtest"""
        try:
            st = speedtest.Speedtester()
            st.get_best_servers()
            upload = st.upload() / 1_000_000  # Convert to Mbps
            download = st.download() / 1_000_000
            ping = st.results.ping
            
            return {
                'upload': round(upload, 2),
                'download': round(download, 2),
                'ping': round(ping, 2),
                'timestamp': datetime.now().isoformat()
            }
        except Exception as e:
            return {
                'error': str(e),
                'upload': 0,
                'download': 0,
                'ping': 0
            }
    
    def get_daily_stats(self) -> Dict:
        """Get daily usage breakdown"""
        return {
            'date': datetime.now().strftime('%Y-%m-%d'),
            'usage_gb': 2.45,
            'peak_hour': '14:00',
            'peak_speed': 45.2
        }
    
    def get_weekly_stats(self) -> Dict:
        """Get weekly usage breakdown"""
        days = []
        for i in range(7):
            date = (datetime.now() - timedelta(days=i)).strftime('%a')
            days.append({
                'day': date,
                'usage_gb': 2.1 + (i * 0.3)
            })
        
        return {
            'week': datetime.now().strftime('Week of %Y-%m-%d'),
            'days': days,
            'total_gb': sum(d['usage_gb'] for d in days)
        }
    
    def get_monthly_stats(self) -> Dict:
        """Get monthly usage breakdown"""
        weeks = []
        for i in range(4):
            weeks.append({
                'week': f'Week {i+1}',
                'usage_gb': 15.5 + (i * 2.1)
            })
        
        return {
            'month': datetime.now().strftime('%B %Y'),
            'weeks': weeks,
            'total_gb': sum(w['usage_gb'] for w in weeks)
        }
    
    def get_system_info(self) -> Dict:
        """Get system information"""
        try:
            cpu_percent = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            disk = psutil.disk_usage('/')
            
            return {
                'hostname': subprocess.check_output(['hostname'], text=True).strip(),
                'os': 'Raspberry Pi OS Lite',
                'kernel': subprocess.check_output(['uname', '-r'], text=True).strip(),
                'uptime': str(datetime.now() - self.start_time).split('.')[0],
                'cpu_usage': cpu_percent,
                'memory': {
                    'used': round(memory.used / (1024**3), 2),
                    'total': round(memory.total / (1024**3), 2),
                    'percent': memory.percent
                },
                'disk': {
                    'used': round(disk.used / (1024**3), 2),
                    'total': round(disk.total / (1024**3), 2),
                    'percent': disk.percent
                },
                'temperature': self._get_cpu_temp()
            }
        except Exception as e:
            return {'error': str(e)}
    
    def _get_cpu_temp(self) -> float:
        """Get CPU temperature"""
        try:
            with open('/sys/class/thermal/thermal_zone0/temp', 'r') as f:
                temp = int(f.read()) / 1000
                return round(temp, 1)
        except:
            return 0.0
    
    def get_logs(self, log_type: str = 'system') -> List[str]:
        """Get system logs"""
        try:
            if log_type == 'system':
                result = subprocess.check_output(['journalctl', '-n', '50'], text=True)
            elif log_type == 'modem':
                result = subprocess.check_output(['journalctl', '-u', 'ModemManager', '-n', '50'],
                                              text=True, stderr=subprocess.DEVNULL)
            else:
                result = subprocess.check_output(['dmesg', '-T'], text=True)
            
            return result.split('\n')[-50:]
        except:
            return ['No logs available']
