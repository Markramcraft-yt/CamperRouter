#!/usr/bin/env python3
"""
Network management for router functionality
Handles hostapd (WiFi AP), dnsmasq (DHCP/DNS), iptables (routing/firewall)
"""

import subprocess
import re
import os
import json
from typing import List, Dict
from datetime import datetime

class NetworkManager:
    def __init__(self):
        self.hostapd_conf = '/etc/hostapd/hostapd.conf'
        self.dnsmasq_conf = '/etc/dnsmasq.conf'
        self.iptables_rules = '/etc/iptables/rules.v4'
    
    def get_connected_devices(self) -> List[Dict]:
        """Get list of connected WiFi devices"""
        try:
            # Get DHCP leases
            result = subprocess.check_output(['cat', '/var/lib/dnsmasq/dnsmasq.leases'],
                                            text=True, stderr=subprocess.DEVNULL)
            devices = []
            
            for line in result.split('\n'):
                if line.strip():
                    parts = line.split()
                    if len(parts) >= 4:
                        devices.append({
                            'mac_address': parts[1],
                            'ip_address': parts[2],
                            'hostname': parts[3] if parts[3] != '*' else 'Unknown',
                            'last_seen': datetime.fromtimestamp(int(parts[0])).isoformat(),
                            'blocked': False,
                            'bandwidth_up': 0,
                            'bandwidth_down': 0
                        })
            
            return devices
        except:
            return []
    
    def get_device_bandwidth(self, mac_address: str) -> Dict:
        """Get bandwidth usage for specific device"""
        try:
            result = subprocess.check_output(['iftop', '-n', '-t', '-s', '1'],
                                            text=True, stderr=subprocess.DEVNULL)
            
            for line in result.split('\n'):
                if mac_address in line:
                    # Parse bandwidth info
                    parts = re.findall(r'[\d.]+\s*[KMG]b', line)
                    if len(parts) >= 2:
                        return {
                            'mac': mac_address,
                            'up': parts[0],
                            'down': parts[1]
                        }
            
            return {'mac': mac_address, 'up': '0 Kb', 'down': '0 Kb'}
        except:
            return {'mac': mac_address, 'up': '0 Kb', 'down': '0 Kb'}
    
    def block_device(self, mac_address: str):
        """Block device from internet access"""
        try:
            # Add iptables rule to block MAC
            subprocess.run([
                'iptables', '-I', 'FORWARD', '-m', 'mac',
                '--mac-source', mac_address, '-j', 'DROP'
            ], check=True)
            subprocess.run(['iptables-save', '>', self.iptables_rules],
                          shell=True, check=True)
            return {'status': 'blocked', 'device': mac_address}
        except:
            return {'error': 'Failed to block device'}
    
    def allow_device(self, mac_address: str):
        """Allow device to access internet"""
        try:
            # Remove iptables rule blocking MAC
            subprocess.run([
                'iptables', '-D', 'FORWARD', '-m', 'mac',
                '--mac-source', mac_address, '-j', 'DROP'
            ], check=True)
            subprocess.run(['iptables-save', '>', self.iptables_rules],
                          shell=True, check=True)
            return {'status': 'allowed', 'device': mac_address}
        except:
            return {'error': 'Failed to allow device'}
    
    def get_wifi_config(self) -> Dict:
        """Get current WiFi configuration"""
        try:
            with open(self.hostapd_conf, 'r') as f:
                config = {}
                for line in f:
                    if '=' in line and not line.startswith('#'):
                        key, value = line.split('=', 1)
                        config[key.strip()] = value.strip()
                
                return {
                    'ssid': config.get('ssid', 'CamperRouter'),
                    'password': config.get('wpa_passphrase', ''),
                    'channel': config.get('channel', '6'),
                    'band': config.get('hw_mode', 'g'),
                    'enabled': True
                }
        except:
            return {
                'ssid': 'CamperRouter',
                'password': 'password123',
                'channel': '6',
                'band': 'g',
                'enabled': False
            }
    
    def set_wifi_config(self, config: Dict):
        """Update WiFi configuration"""
        try:
            with open(self.hostapd_conf, 'w') as f:
                f.write(f"ssid={config.get('ssid', 'CamperRouter')}\n")
                f.write(f"wpa_passphrase={config.get('password', '')}\n")
                f.write(f"channel={config.get('channel', '6')}\n")
                f.write(f"hw_mode={config.get('band', 'g')}\n")
            
            # Restart hostapd
            subprocess.run(['systemctl', 'restart', 'hostapd'], check=True)
            return {'status': 'updated'}
        except Exception as e:
            return {'error': str(e)}
    
    def get_lan_config(self) -> Dict:
        """Get LAN configuration"""
        return {
            'direction': 'in',
            'autodetect': True,
            'interface': 'eth0',
            'ip': '192.168.1.1',
            'netmask': '255.255.255.0'
        }
    
    def set_lan_config(self, config: Dict):
        """Update LAN configuration"""
        # Would update network interfaces file
        return {'status': 'updated'}
    
    def get_firewall_rules(self) -> List[Dict]:
        """Get current firewall rules"""
        try:
            result = subprocess.check_output(['iptables', '-L', '-n'], text=True)
            rules = []
            for line in result.split('\n'):
                if 'ACCEPT' in line or 'DROP' in line or 'REJECT' in line:
                    rules.append({'rule': line.strip()})
            return rules
        except:
            return []
    
    def add_firewall_rule(self, rule: Dict):
        """Add firewall rule"""
        try:
            cmd = ['iptables', '-A', rule.get('chain', 'INPUT')]
            if rule.get('protocol'):
                cmd.extend(['-p', rule['protocol']])
            if rule.get('port'):
                cmd.extend(['--dport', str(rule['port'])])
            cmd.extend(['-j', rule.get('action', 'ACCEPT')])
            
            subprocess.run(cmd, check=True)
            return {'status': 'added'}
        except Exception as e:
            return {'error': str(e)}
    
    def get_portforward_rules(self) -> List[Dict]:
        """Get port forwarding rules"""
        try:
            result = subprocess.check_output(['iptables', '-t', 'nat', '-L', '-n'],
                                            text=True)
            rules = []
            for line in result.split('\n'):
                if 'DNAT' in line:
                    rules.append({'rule': line.strip()})
            return rules
        except:
            return []
    
    def add_portforward_rule(self, rule: Dict):
        """Add port forwarding rule"""
        try:
            cmd = [
                'iptables', '-t', 'nat', '-A', 'PREROUTING',
                '-p', rule.get('protocol', 'tcp'),
                '--dport', str(rule.get('port', 80)),
                '-j', 'DNAT',
                '--to-destination', rule.get('destination', '192.168.1.100')
            ]
            subprocess.run(cmd, check=True)
            return {'status': 'added'}
        except Exception as e:
            return {'error': str(e)}
    
    def get_dns_config(self) -> Dict:
        """Get DNS configuration"""
        return {
            'primary': '8.8.8.8',
            'secondary': '8.8.4.4',
            'cache_enabled': True,
            'adblock': False
        }
    
    def set_dns_config(self, config: Dict):
        """Update DNS configuration"""
        return {'status': 'updated'}
    
    def get_dhcp_config(self) -> Dict:
        """Get DHCP configuration"""
        return {
            'enabled': True,
            'range_start': '192.168.1.100',
            'range_end': '192.168.1.254',
            'lease_time': '24h',
            'gateway': '192.168.1.1'
        }
    
    def set_dhcp_config(self, config: Dict):
        """Update DHCP configuration"""
        return {'status': 'updated'}
    
    def backup_config(self) -> Dict:
        """Backup configuration"""
        backup = {
            'wifi': self.get_wifi_config(),
            'lan': self.get_lan_config(),
            'dns': self.get_dns_config(),
            'dhcp': self.get_dhcp_config(),
            'timestamp': datetime.now().isoformat()
        }
        return backup
    
    def restore_config(self, backup: Dict):
        """Restore configuration from backup"""
        if 'wifi' in backup:
            self.set_wifi_config(backup['wifi'])
        if 'lan' in backup:
            self.set_lan_config(backup['lan'])
        return {'status': 'restored'}
