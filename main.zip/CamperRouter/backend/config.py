#!/usr/bin/env python3
"""
Configuration manager for app settings
"""

import json
import os

CONFIG_FILE = '/etc/camper-router/config.json'

class Config:
    _cache = {}
    
    @staticmethod
    def load():
        """Load config from file"""
        try:
            with open(CONFIG_FILE, 'r') as f:
                Config._cache = json.load(f)
        except:
            Config._cache = {
                'brightness': 100,
                'wifi_ssid': 'CamperRouter',
                'wifi_password': 'password123',
                'timezone': 'UTC',
                'auto_backup': True,
                'notification_enabled': True
            }
    
    @staticmethod
    def get(key: str, default=None):
        """Get config value"""
        if not Config._cache:
            Config.load()
        return Config._cache.get(key, default)
    
    @staticmethod
    def set(key: str, value):
        """Set config value"""
        if not Config._cache:
            Config.load()
        Config._cache[key] = value
        Config.save()
    
    @staticmethod
    def save():
        """Save config to file"""
        os.makedirs(os.path.dirname(CONFIG_FILE), exist_ok=True)
        with open(CONFIG_FILE, 'w') as f:
            json.dump(Config._cache, f, indent=2)

# Load on import
Config.load()
