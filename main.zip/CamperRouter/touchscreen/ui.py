#!/usr/bin/env python3
"""
CamperRouter - PyGame Touchscreen UI
Displays router stats on 3.5" GPIO touchscreen (480x320)
"""

import pygame
import sys
import requests
import json
from datetime import datetime
from enum import Enum

# Screen dimensions for 3.5" HVGA touchscreen
SCREEN_WIDTH = 480
SCREEN_HEIGHT = 320
FPS = 30

# Colors
COLOR_BG = (20, 20, 30)
COLOR_TEXT = (255, 255, 255)
COLOR_ACCENT = (0, 150, 255)
COLOR_DANGER = (255, 50, 50)
COLOR_SUCCESS = (50, 200, 50)

class Screen(Enum):
    """Screen states for navigation"""
    STARTUP = 0
    LOCK = 1
    DASHBOARD = 2
    DEVICES = 3
    SPEEDTEST = 4
    STATS = 5
    SETTINGS = 6
    NOTIFICATIONS = 7
    NETWORK_MAP = 8
    QR_CODE = 9
    ABOUT = 10

class TouchscreenUI:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption('CamperRouter')
        self.clock = pygame.time.Clock()
        self.font_small = pygame.font.Font(None, 16)
        self.font_med = pygame.font.Font(None, 24)
        self.font_large = pygame.font.Font(None, 32)
        self.font_xl = pygame.font.Font(None, 48)
        
        self.current_screen = Screen.STARTUP
        self.password = ""
        self.password_input = ""
        self.locked = True
        self.stats = {}
        
        self.api_base = 'http://localhost:5000/api'
        self.swipe_start = None
        self.swipe_threshold = 50
    
    def run(self):
        """Main event loop"""
        running = True
        while running:
            running = self.handle_events()
            self.update()
            self.draw()
            self.clock.tick(FPS)
        
        pygame.quit()
        sys.exit()
    
    def handle_events(self) -> bool:
        """Handle input events"""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            
            if event.type == pygame.MOUSEBUTTONDOWN:
                self.swipe_start = event.pos
            
            if event.type == pygame.MOUSEBUTTONUP:
                if self.swipe_start:
                    self.handle_swipe(self.swipe_start, event.pos)
                self.swipe_start = None
            
            if event.type == pygame.KEYDOWN:
                if self.current_screen == Screen.LOCK:
                    if event.key == pygame.K_BACKSPACE:
                        self.password_input = self.password_input[:-1]
                    elif event.key == pygame.K_RETURN:
                        self.check_password()
                    elif event.unicode.isalnum():
                        self.password_input += event.unicode
        
        return True
    
    def handle_swipe(self, start: tuple, end: tuple):
        """Handle swipe gestures"""
        dx = end[0] - start[0]
        dy = end[1] - start[1]
        
        if abs(dx) > self.swipe_threshold:
            if dx > 0:  # Swipe right
                self.on_swipe_right()
            elif dx < 0:  # Swipe left
                self.on_swipe_left()
        
        if abs(dy) > self.swipe_threshold:
            if dy < 0:  # Swipe up (opens app switcher)
                self.on_swipe_up()
            elif dy > 0:  # Swipe down (notifications)
                self.on_swipe_down()
    
    def on_swipe_left(self):
        """Handle left swipe (go to lock screen)"""
        if self.current_screen == Screen.STARTUP:
            self.current_screen = Screen.LOCK
            self.password_input = ""
    
    def on_swipe_right(self):
        """Handle right swipe (back to previous)"""
        if self.current_screen != Screen.DASHBOARD:
            self.current_screen = Screen.DASHBOARD
    
    def on_swipe_up(self):
        """Handle swipe up (back to startup clock, no re-login)"""
        self.current_screen = Screen.STARTUP
    
    def on_swipe_down(self):
        """Handle swipe down (notifications panel)"""
        if self.current_screen == Screen.DASHBOARD:
            self.current_screen = Screen.NOTIFICATIONS
    
    def check_password(self):
        """Check if password is correct"""
        if self.password_input == "1234":  # TODO: Load from config
            self.locked = False
            self.current_screen = Screen.DASHBOARD
            self.password_input = ""
        else:
            self.password_input = ""
    
    def update(self):
        """Update game state"""
        # Fetch latest stats
        try:
            response = requests.get(f'{self.api_base}/stats', timeout=1)
            self.stats = response.json()
        except:
            pass
    
    def draw(self):
        """Draw current screen"""
        self.screen.fill(COLOR_BG)
        
        if self.current_screen == Screen.STARTUP:
            self.draw_startup()
        elif self.current_screen == Screen.LOCK:
            self.draw_lock()
        elif self.current_screen == Screen.DASHBOARD:
            self.draw_dashboard()
        elif self.current_screen == Screen.DEVICES:
            self.draw_devices()
        elif self.current_screen == Screen.SPEEDTEST:
            self.draw_speedtest()
        elif self.current_screen == Screen.STATS:
            self.draw_stats()
        elif self.current_screen == Screen.SETTINGS:
            self.draw_settings()
        elif self.current_screen == Screen.NOTIFICATIONS:
            self.draw_notifications()
        elif self.current_screen == Screen.NETWORK_MAP:
            self.draw_network_map()
        elif self.current_screen == Screen.QR_CODE:
            self.draw_qr_code()
        elif self.current_screen == Screen.ABOUT:
            self.draw_about()
        
        pygame.display.flip()
    
    def draw_top_bar(self):
        """Draw top status bar"""
        # Time and date
        now = datetime.now()
        time_str = now.strftime('%H:%M')
        date_str = now.strftime('%d/%m/%Y')
        
        time_text = self.font_small.render(time_str, True, COLOR_TEXT)
        date_text = self.font_small.render(date_str, True, COLOR_TEXT)
        
        self.screen.blit(time_text, (10, 5))
        self.screen.blit(date_text, (120, 5))
        
        # SIM indicator
        try:
            sims = requests.get(f'{self.api_base}/sims', timeout=1).json()
            for i, sim in enumerate(sims['sims']):
                sim_text = self.font_small.render(f"SIM {i+1}: 📶", True, COLOR_TEXT)
                self.screen.blit(sim_text, (300 + i*70, 5))
        except:
            pass
        
        # Settings button
        settings_text = self.font_med.render("⚙️", True, COLOR_ACCENT)
        self.screen.blit(settings_text, (460, 5))
        
        # Divider line
        pygame.draw.line(self.screen, COLOR_ACCENT, (0, 30), (SCREEN_WIDTH, 30), 1)
    
    def draw_startup(self):
        """Draw startup clock screen"""
        now = datetime.now()
        time_str = now.strftime('%H:%M:%S')
        date_str = now.strftime('%A, %B %d, %Y')
        
        time_surf = self.font_xl.render(time_str, True, COLOR_ACCENT)
        date_surf = self.font_med.render(date_str, True, COLOR_TEXT)
        
        time_rect = time_surf.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2 - 30))
        date_rect = date_surf.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2 + 30))
        
        self.screen.blit(time_surf, time_rect)
        self.screen.blit(date_surf, date_rect)
        
        # Hint text
        hint = self.font_small.render("← Swipe left to unlock", True, COLOR_TEXT)
        self.screen.blit(hint, (10, SCREEN_HEIGHT - 25))
    
    def draw_lock(self):
        """Draw lock screen with password input"""
        title = self.font_large.render("CamperRouter", True, COLOR_ACCENT)
        title_rect = title.get_rect(center=(SCREEN_WIDTH//2, 50))
        self.screen.blit(title, title_rect)
        
        # Password input
        input_text = self.font_med.render("•" * len(self.password_input), True, COLOR_TEXT)
        input_rect = input_text.get_rect(center=(SCREEN_WIDTH//2, 120))
        self.screen.blit(input_text, input_rect)
        
        # Buttons
        pygame.draw.rect(self.screen, COLOR_ACCENT, (50, 180, 100, 40))
        pygame.draw.rect(self.screen, COLOR_DANGER, (180, 180, 100, 40))
        pygame.draw.rect(self.screen, (100, 100, 100), (310, 180, 100, 40))
        
        restart_text = self.font_small.render("Restart", True, COLOR_BG)
        sleep_text = self.font_small.render("Sleep", True, COLOR_BG)
        shutdown_text = self.font_small.render("Shutdown", True, COLOR_BG)
        
        self.screen.blit(restart_text, (70, 195))
        self.screen.blit(sleep_text, (205, 195))
        self.screen.blit(shutdown_text, (315, 195))
    
    def draw_dashboard(self):
        """Draw main dashboard"""
        self.draw_top_bar()
        
        # GB Used (large)
        gb_text = self.font_large.render(f"{self.stats.get('gb_used', 0)} GB", True, COLOR_ACCENT)
        gb_label = self.font_med.render("Used Since Setup", True, COLOR_TEXT)
        
        gb_rect = gb_text.get_rect(center=(SCREEN_WIDTH//2, 90))
        label_rect = gb_label.get_rect(center=(SCREEN_WIDTH//2, 130))
        
        self.screen.blit(gb_text, gb_rect)
        self.screen.blit(gb_label, label_rect)
        
        # Upload/Download speeds
        up_speed = self.font_med.render(
            f"↑ {self.stats.get('upload_mbps', 0)} Mbps",
            True, COLOR_SUCCESS
        )
        down_speed = self.font_med.render(
            f"↓ {self.stats.get('download_mbps', 0)} Mbps",
            True, COLOR_SUCCESS
        )
        
        self.screen.blit(up_speed, (20, 200))
        self.screen.blit(down_speed, (250, 200))
    
    def draw_devices(self):
        """Draw connected devices screen"""
        self.draw_top_bar()
        
        title = self.font_med.render("Connected Devices", True, COLOR_ACCENT)
        self.screen.blit(title, (20, 40))
        
        # Would draw device list here
    
    def draw_speedtest(self):
        """Draw speedtest screen"""
        self.draw_top_bar()
        
        title = self.font_med.render("Speed Test", True, COLOR_ACCENT)
        self.screen.blit(title, (20, 40))
    
    def draw_stats(self):
        """Draw statistics screen"""
        self.draw_top_bar()
        
        title = self.font_med.render("Statistics", True, COLOR_ACCENT)
        self.screen.blit(title, (20, 40))
    
    def draw_settings(self):
        """Draw settings screen"""
        self.draw_top_bar()
        
        title = self.font_med.render("Settings", True, COLOR_ACCENT)
        self.screen.blit(title, (20, 40))
    
    def draw_notifications(self):
        """Draw notifications panel"""
        self.draw_top_bar()
        
        title = self.font_med.render("Notifications", True, COLOR_ACCENT)
        self.screen.blit(title, (20, 40))
    
    def draw_network_map(self):
        """Draw network map"""
        self.draw_top_bar()
        
        title = self.font_med.render("Network Map", True, COLOR_ACCENT)
        self.screen.blit(title, (20, 40))
    
    def draw_qr_code(self):
        """Draw QR code for WiFi"""
        self.draw_top_bar()
        
        title = self.font_med.render("WiFi QR Code", True, COLOR_ACCENT)
        self.screen.blit(title, (20, 40))
    
    def draw_about(self):
        """Draw about screen"""
        self.draw_top_bar()
        
        title = self.font_med.render("CamperRouter v1.0.0", True, COLOR_ACCENT)
        author = self.font_small.render("by Markramcraft", True, COLOR_TEXT)
        license = self.font_small.render("GPL-3.0", True, COLOR_TEXT)
        
        self.screen.blit(title, (50, 100))
        self.screen.blit(author, (50, 150))
        self.screen.blit(license, (50, 200))

if __name__ == '__main__':
    ui = TouchscreenUI()
    ui.run()
