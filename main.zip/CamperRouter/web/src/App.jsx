import React, { useState, useEffect } from 'react';
import './App.css';

const API_BASE = 'http://localhost:5000/api';

function App() {
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [stats, setStats] = useState({});
  const [connection, setConnection] = useState({});
  const [devices, setDevices] = useState([]);
  const [isLocked, setIsLocked] = useState(true);
  const [password, setPassword] = useState('');

  useEffect(() => {
    const interval = setInterval(() => {
      fetch(`${API_BASE}/stats`)
        .then(r => r.json())
        .then(setStats)
        .catch(console.error);

      fetch(`${API_BASE}/modem/connection`)
        .then(r => r.json())
        .then(setConnection)
        .catch(console.error);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    fetch(`${API_BASE}/devices`)
      .then(r => r.json())
      .then(d => setDevices(d.devices))
      .catch(console.error);
  }, []);

  const handleUnlock = () => {
    if (password === '1234') {
      setIsLocked(false);
    } else {
      alert('Wrong password');
    }
  };

  if (isLocked) {
    return (
      <div className="lock-screen">
        <h1>CamperRouter</h1>
        <input
          type="password"
          value={password}
          onChange={e => setPassword(e.target.value)}
          onKeyPress={e => e.key === 'Enter' && handleUnlock()}
          placeholder="Enter password"
          autoFocus
        />
        <button onClick={handleUnlock}>Unlock</button>
      </div>
    );
  }

  return (
    <div className="app">
      <nav className="navbar">
        <button 
          className={currentPage === 'dashboard' ? 'active' : ''} 
          onClick={() => setCurrentPage('dashboard')}
        >
          Dashboard
        </button>
        <button 
          className={currentPage === 'devices' ? 'active' : ''} 
          onClick={() => setCurrentPage('devices')}
        >
          Devices
        </button>
        <button 
          className={currentPage === 'speedtest' ? 'active' : ''} 
          onClick={() => setCurrentPage('speedtest')}
        >
          Speed Test
        </button>
        <button 
          className={currentPage === 'stats' ? 'active' : ''} 
          onClick={() => setCurrentPage('stats')}
        >
          Stats
        </button>
        <button 
          className={currentPage === 'settings' ? 'active' : ''} 
          onClick={() => setCurrentPage('settings')}
        >
          Settings
        </button>
      </nav>

      <div className="content">
        {currentPage === 'dashboard' && <Dashboard stats={stats} connection={connection} />}
        {currentPage === 'devices' && <Devices devices={devices} />}
        {currentPage === 'speedtest' && <SpeedTest />}
        {currentPage === 'stats' && <Stats />}
        {currentPage === 'settings' && <Settings />}
      </div>
    </div>
  );
}

function Dashboard({ stats, connection }) {
  return (
    <div className="dashboard">
      <div className="connection-bar">
        <span>📡 {connection.connection_type || 'Unknown'}</span>
        <span>🏢 {connection.provider || 'Unknown'}</span>
      </div>

      <h1>Dashboard</h1>
      <div className="stats-grid">
        <div className="stat-card">
          <h2>{stats.gb_used} GB</h2>
          <p>Used Since Setup</p>
        </div>
        <div className="stat-card">
          <h2>{stats.upload_mbps} Mbps</h2>
          <p>↑ Upload Speed</p>
        </div>
        <div className="stat-card">
          <h2>{stats.download_mbps} Mbps</h2>
          <p>↓ Download Speed</p>
        </div>
      </div>
    </div>
  );
}

function Devices({ devices }) {
  return (
    <div className="devices">
      <h1>Connected Devices</h1>
      {devices.length === 0 ? (
        <p>No devices connected</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Hostname</th>
              <th>IP Address</th>
              <th>MAC Address</th>
              <th>Bandwidth</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {devices.map(d => (
              <tr key={d.mac_address}>
                <td>{d.hostname}</td>
                <td>{d.ip_address}</td>
                <td>{d.mac_address}</td>
                <td>↑ {d.bandwidth_up} ↓ {d.bandwidth_down}</td>
                <td>
                  <button>Block</button>
                  <button>Info</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

function SpeedTest() {
  const [running, setRunning] = useState(false);

  const handleRun = async () => {
    setRunning(true);
    try {
      await fetch(`${API_BASE}/speedtest/run`, { method: 'POST' });
      setTimeout(() => setRunning(false), 60000);
    } catch (e) {
      console.error(e);
      setRunning(false);
    }
  };

  return (
    <div className="speedtest">
      <h1>Speed Test</h1>
      <button onClick={handleRun} disabled={running}>
        {running ? 'Running...' : 'Run Speed Test'}
      </button>
    </div>
  );
}

function Stats() {
  const [stats, setStats] = useState({});

  useEffect(() => {
    Promise.all([
      fetch(`${API_BASE}/statistics/daily`).then(r => r.json()),
      fetch(`${API_BASE}/statistics/weekly`).then(r => r.json())
    ]).then(([daily, weekly]) => {
      setStats({ daily, weekly });
    });
  }, []);

  return (
    <div className="stats">
      <h1>Statistics</h1>
      <div className="stats-section">
        <h2>Daily Usage</h2>
        {stats.daily && (
          <p>{stats.daily.usage_gb} GB on {stats.daily.date}</p>
        )}
      </div>
      <div className="stats-section">
        <h2>Weekly Usage</h2>
        {stats.weekly && (
          <p>{stats.weekly.total_gb} GB this week</p>
        )}
      </div>
    </div>
  );
}

function Settings() {
  const [wifi, setWifi] = useState({});
  const [brightness, setBrightness] = useState(100);

  useEffect(() => {
    fetch(`${API_BASE}/wifi`)
      .then(r => r.json())
      .then(setWifi)
      .catch(console.error);

    fetch(`${API_BASE}/brightness`)
      .then(r => r.json())
      .then(d => setBrightness(d.brightness))
      .catch(console.error);
  }, []);

  return (
    <div className="settings">
      <h1>Settings</h1>

      <div className="settings-section">
        <h2>WiFi</h2>
        <label>
          SSID:
          <input type="text" defaultValue={wifi.ssid} />
        </label>
        <label>
          Password:
          <input type="password" defaultValue={wifi.password} />
        </label>
        <button>Save</button>
      </div>

      <div className="settings-section">
        <h2>Brightness</h2>
        <input 
          type="range" 
          min="0" 
          max="100" 
          value={brightness} 
          onChange={e => setBrightness(e.target.value)}
        />
        <p>{brightness}%</p>
      </div>
    </div>
  );
}

export default App;
