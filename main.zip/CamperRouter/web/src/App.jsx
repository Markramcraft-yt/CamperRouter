import React, { useState, useEffect } from 'react';
import './App.css';

// API client
const API_BASE = 'http://localhost:5000/api';

function App() {
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [stats, setStats] = useState({});
  const [devices, setDevices] = useState([]);
  const [isLocked, setIsLocked] = useState(true);
  const [password, setPassword] = useState('');

  useEffect(() => {
    // Fetch stats periodically
    const interval = setInterval(() => {
      fetch(`${API_BASE}/stats`)
        .then(r => r.json())
        .then(setStats)
        .catch(console.error);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    // Fetch devices
    fetch(`${API_BASE}/devices`)
      .then(r => r.json())
      .then(d => setDevices(d.devices))
      .catch(console.error);
  }, []);

  const handleUnlock = () => {
    if (password === '1234') {
      setIsLocked(false);
    } else {
      alert('Wrong password');
    }
  };

  if (isLocked) {
    return (
      <div className="lock-screen">
        <h1>CamperRouter</h1>
        <input
          type="password"
          value={password}
          onChange={e => setPassword(e.target.value)}
          onKeyPress={e => e.key === 'Enter' && handleUnlock()}
          placeholder="Enter password"
        />
        <button onClick={handleUnlock}>Unlock</button>
      </div>
    );
  }

  return (
    <div className="app">
      <nav className="navbar">
        <button onClick={() => setCurrentPage('dashboard')}>Dashboard</button>
        <button onClick={() => setCurrentPage('devices')}>Devices</button>
        <button onClick={() => setCurrentPage('speedtest')}>Speed Test</button>
        <button onClick={() => setCurrentPage('stats')}>Stats</button>
        <button onClick={() => setCurrentPage('settings')}>Settings</button>
      </nav>

      <div className="content">
        {currentPage === 'dashboard' && <Dashboard stats={stats} />}
        {currentPage === 'devices' && <Devices devices={devices} />}
        {currentPage === 'speedtest' && <SpeedTest />}
        {currentPage === 'stats' && <Stats />}
        {currentPage === 'settings' && <Settings />}
      </div>
    </div>
  );
}

function Dashboard({ stats }) {
  return (
    <div className="dashboard">
      <h1>Dashboard</h1>
      <div className="stats-grid">
        <div className="stat-card">
          <h2>{stats.gb_used} GB</h2>
          <p>Used Since Setup</p>
        </div>
        <div className="stat-card">
          <p>↑ {stats.upload_mbps} Mbps</p>
          <p>Upload Speed</p>
        </div>
        <div className="stat-card">
          <p>↓ {stats.download_mbps} Mbps</p>
          <p>Download Speed</p>
        </div>
      </div>
    </div>
  );
}

function Devices({ devices }) {
  return (
    <div className="devices">
      <h1>Connected Devices</h1>
      <table>
        <thead>
          <tr>
            <th>Hostname</th>
            <th>IP Address</th>
            <th>MAC Address</th>
            <th>Bandwidth</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {devices.map(d => (
            <tr key={d.mac_address}>
              <td>{d.hostname}</td>
              <td>{d.ip_address}</td>
              <td>{d.mac_address}</td>
              <td>↑ {d.bandwidth_up} ↓ {d.bandwidth_down}</td>
              <td>
                <button>Block</button>
                <button>Allow</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function SpeedTest() {
  return (
    <div className="speedtest">
      <h1>Speed Test</h1>
      <button>Run Speed Test</button>
    </div>
  );
}

function Stats() {
  return (
    <div className="stats">
      <h1>Statistics</h1>
      <h2>Daily Usage</h2>
      {/* Would show charts here */}
      <h2>Weekly Usage</h2>
      {/* Would show charts here */}
    </div>
  );
}

function Settings() {
  return (
    <div className="settings">
      <h1>Settings</h1>
      <h2>WiFi</h2>
      <label>SSID: <input type="text" /></label>
      <label>Password: <input type="password" /></label>
      <button>Save</button>
    </div>
  );
}

export default App;
