# CamperRouter v1.0.0

Custom 5G/4G/LTE router OS for Raspberry Pi 3 with real-time monitoring and multi-SIM support.

## Features

### Dashboard
- **Real-time stats**: GB used, upload/download speeds
- **Connection type display**: Shows 5G/4G/3G + carrier provider
- **SIM management**: Detect SIMs, enable/disable roaming, set failover
- **Device monitoring**: Connected devices, bandwidth per device
- **Speed test**: Run Ookla speedtests, view history
- **Network map**: Visualize connected devices

### Web Interface (React)
- Full-featured dashboard at `http://raspberrypi.local:5000`
- Lock-protected with customizable password
- Settings for WiFi, LAN, brightness, DNS, DHCP
- Firewall and port forwarding rules
- System logs and backup/restore

### Hardware
- Raspberry Pi 3
- 5G/4G/LTE USB modem with SIM slot (e.g., BOJIADAFAST, SDX55)
- USB WiFi dongle (optional, for AP mode)
- Power supply (5V 2.5A minimum)

## Quick Start

### 1. Flash Raspberry Pi OS Lite (32-bit)
```bash
sudo apt update && sudo apt upgrade -y
```

### 2. Download CamperRouter
```bash
wget https://github.com/Markramcraft-yt/CamperRouter/archive/refs/heads/main.zip
unzip main.zip
cd CamperRouter-main
```

### 3. Run Setup
```bash
sudo bash setup.sh
```

### 4. Insert SIM and Plug in Modem
ModemManager will auto-detect your USB modem.

### 5. Start Backend
```bash
sudo systemctl start camper-router-backend
```

### 6. Access Dashboard
- Web: `http://raspberrypi.local:5000`
- Password: `1234`
- WiFi SSID: `CamperRouter`
- WiFi Password: `password123`

## API Endpoints

### Dashboard
- `GET /api/stats` — GB used, speeds
- `GET /api/sims` — Detected SIMs with roaming status
- `GET /api/modem/connection` — Connection type (5G/4G/3G) + provider
- `GET /api/devices` — Connected devices
- `GET /api/speedtest/history` — Speed test results
- `GET /api/statistics/{daily|weekly|monthly}` — Usage breakdown

### Settings
- `GET /api/wifi` — WiFi config
- `POST /api/wifi` — Update WiFi
- `GET /api/brightness` — Screen brightness
- `POST /api/brightness` — Set brightness
- `GET /api/system/info` — System information

### SIM Management
- `POST /api/sims/<id>/roaming` — Enable/disable roaming
- `POST /api/sims/<id>/priority` — Set SIM priority (primary/backup)
- `POST /api/sims/failover` — Enable auto-failover

### Web-Only
- `GET /api/firewall` — Firewall rules
- `POST /api/firewall` — Add rule
- `GET /api/portforward` — Port forwards
- `POST /api/portforward` — Add forward
- `GET /api/dns` — DNS config
- `POST /api/dns` — Update DNS
- `GET /api/dhcp` — DHCP config
- `POST /api/dhcp` — Update DHCP
- `POST /api/backup` — Backup config
- `POST /api/restore` — Restore config

## Configuration

Edit `/etc/camper-router/config.json`:
```json
{
  "password": "1234",
  "wifi_ssid": "CamperRouter",
  "wifi_password": "password123",
  "brightness": 100,
  "modem": {
    "type": "5G_USB_Modem",
    "enabled": true,
    "autoconnect": true
  }
}
```

## Recommended Hardware

- **5G Modem**: BOJIADAFAST, SDX55 LTE 4G 5G (~RON113-349)
- **Antennas**: RP-SMA connectors (~RON20-40)
- **WiFi Dongle**: Any USB 2.4/5GHz adapter

## Directory Structure

```
CamperRouter/
├── backend/
│   └── app.py (Flask API server)
├── web/
│   ├── src/
│   │   ├── App.jsx (React dashboard)
│   │   └── App.css (Styling)
│   └── package.json
├── setup.sh (Installation script)
├── requirements.txt (Python dependencies)
├── config.json.example (Config template)
├── LICENSE (GPL-3.0)
└── README.md (This file)
```

## License

GPL-3.0 - See LICENSE file

## Author

Markramcraft - 2026

## Support

Issues? Check:
1. ModemManager is installed: `sudo apt install modemmanager`
2. Modem is detected: `mmcli -L`
3. Backend is running: `sudo systemctl status camper-router-backend`
4. Check logs: `sudo journalctl -u camper-router-backend -f`

---

**For camper adventures and vacation connectivity!** 🏕️📡
