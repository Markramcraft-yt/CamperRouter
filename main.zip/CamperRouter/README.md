# CamperRouter - Custom Router OS for Raspberry Pi 3

A full-stack custom router operating system for Raspberry Pi 3 with 4G/LTE modem support, dual-interface (touchscreen + web dashboard), and comprehensive network management.

## Features

### Touchscreen UI (PyGame - 480x320)
- Dashboard (GB used, upload/download speeds, SIM status)
- Connected Devices (list, bandwidth per device)
- Speed Test (run tests, view history)
- Statistics (graphs, daily/weekly/monthly breakdown)
- Settings (WiFi, LAN, Brightness, Advanced, Updates, System Info)
- Lock Screen (password protected)
- Startup Clock (minimal boot screen)
- Notifications (alerts, logs, events)
- Network Map (device visualization)
- QR Code (WiFi quick connect)
- About (version, credits, license)

### Web Dashboard (React)
- All touchscreen features PLUS:
- Modem Control (on/off, reset, signal strength)
- Port Forwarding (add/edit/delete rules)
- Firewall (view/edit rules)
- DNS Settings (custom DNS, cache)
- DHCP (lease info, IP range)
- VPN (OpenVPN/Wireguard)
- Ad-Blocking (Pi-hole integration)
- Parental Controls (scheduled access)
- System Logs (view all logs)
- Backup/Restore (config management)

## Hardware Required

- Raspberry Pi 3
- USB 4G/LTE Modem (with SIM slot)
- 3.5" GPIO Touchscreen (SPI, WTP-AC3 compatible)
- USB WiFi dongle (for AP mode)
- Power supply (5V 2.5A minimum)

## Installation

### 1. Flash Raspberry Pi OS Lite (32-bit)

```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y python3-pip python3-dev git
```

### 2. Install Dependencies

```bash
sudo apt install -y hostapd dnsmasq iptables-persistent modemmanager
sudo apt install -y libgpiod-dev libgpiod2
pip3 install flask flask-cors pygame numpy psutil
pip3 install speedtest-cli iftop
```

### 3. Clone and Setup

```bash
git clone https://github.com/yourusername/CamperRouter.git
cd CamperRouter
chmod +x setup.sh
sudo ./setup.sh
```

### 4. Configure GPIO Touchscreen

Edit `/boot/firmware/config.txt`:
```
dtoverlay=spi0-1cs,cs0_pin=8
dtoverlay=gpio-ir,gpio_pin=17
```

Reboot and configure touch calibration via `raspi-config`.

### 5. Start Services

```bash
sudo systemctl enable camper-router-backend
sudo systemctl enable camper-router-ui
sudo systemctl start camper-router-backend
sudo systemctl start camper-router-ui
```

## Access

- **Web Dashboard:** http://raspberrypi.local:5000
- **Touchscreen UI:** Auto-launches on boot (PyGame fullscreen)

## Architecture

```
CamperRouter/
├── backend/
│   ├── app.py (Flask API server)
│   ├── modem.py (ModemManager integration)
│   ├── network.py (hostapd, dnsmasq, iptables control)
│   ├── stats.py (data tracking, speed monitoring)
│   ├── database.py (SQLite models)
│   └── config.py (default configurations)
├── touchscreen/
│   ├── ui.py (PyGame main app)
│   ├── screens/ (page implementations)
│   ├── gestures.py (swipe detection)
│   └── assets/ (fonts, icons)
├── web/
│   ├── src/
│   │   ├── components/ (React components)
│   │   ├── pages/ (page layouts)
│   │   ├── api.js (API client)
│   │   └── App.jsx (main app)
│   ├── public/
│   └── package.json
├── systemd/
│   ├── camper-router-backend.service
│   └── camper-router-ui.service
├── setup.sh (installation script)
└── README.md (this file)
```

## API Endpoints

### Dashboard
- `GET /api/stats` — GB used, upload/download speeds
- `GET /api/sims` — detect SIM cards
- `GET /api/signal` — signal strength

### Devices
- `GET /api/devices` — connected devices
- `POST /api/devices/{id}/block` — block device
- `POST /api/devices/{id}/allow` — allow device

### Speed Test
- `POST /api/speedtest/run` — run speedtest
- `GET /api/speedtest/history` — test results

### Settings
- `GET /api/wifi` — WiFi config
- `POST /api/wifi` — update WiFi
- `GET /api/brightness` — current brightness
- `POST /api/brightness` — set brightness

### Modem (Web only)
- `POST /api/modem/toggle` — on/off
- `POST /api/modem/reset` — reset modem
- `GET /api/modem/info` — carrier, signal, etc.

### Network (Web only)
- `GET /api/firewall` — firewall rules
- `POST /api/firewall` — add rule
- `GET /api/portforward` — port forwards
- `POST /api/portforward` — add rule
- `GET /api/dns` — DNS config
- `POST /api/dns` — update DNS
- `GET /api/dhcp` — DHCP status
- `POST /api/dhcp` — update DHCP

## License

GPL-3.0

## Author

Markramcraft
