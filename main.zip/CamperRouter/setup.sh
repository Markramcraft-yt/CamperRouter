#!/bin/bash
# CamperRouter Setup Script
# Installation and configuration for Raspberry Pi 3

set -e

echo "=========================================="
echo "CamperRouter - Setup Script"
echo "=========================================="

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
  echo "Please run as root (sudo)"
  exit 1
fi

# Update system
echo "[*] Updating system..."
apt update && apt upgrade -y

# Install dependencies
echo "[*] Installing dependencies..."
apt install -y \
  python3-pip \
  python3-dev \
  git \
  hostapd \
  dnsmasq \
  iptables-persistent \
  modemmanager \
  libgpiod-dev \
  libgpiod2 \
  nodejs \
  npm

# Install Python packages
echo "[*] Installing Python packages..."
pip3 install -r requirements.txt

# Create directories
echo "[*] Creating directories..."
mkdir -p /var/lib/camper-router
mkdir -p /etc/camper-router
mkdir -p /opt/camper-router

# Copy files
echo "[*] Copying application files..."
cp -r backend /opt/camper-router/
cp -r touchscreen /opt/camper-router/
cp -r web /opt/camper-router/

# Copy config
echo "[*] Setting up configuration..."
cp config.json.example /etc/camper-router/config.json

# Setup hostapd
echo "[*] Configuring hostapd..."
cat > /etc/hostapd/hostapd.conf <<EOF
interface=wlan0
driver=nl80211
ssid=CamperRouter
hw_mode=g
channel=6
wmm_enabled=1
wpa=2
wpa_passphrase=password123
wpa_key_mgmt=WPA-PSK
wpa_pairwise=CCMP
wpa_ptk_rekey=600
EOF

# Setup dnsmasq
echo "[*] Configuring dnsmasq..."
cat > /etc/dnsmasq.conf <<EOF
interface=wlan0
dhcp-range=192.168.1.100,192.168.1.254,255.255.255.0,24h
dhcp-option=option:router,192.168.1.1
dhcp-leasefile=/var/lib/dnsmasq/dnsmasq.leases
EOF

mkdir -p /var/lib/dnsmasq

# Setup systemd services
echo "[*] Installing systemd services..."
cat > /etc/systemd/system/camper-router-backend.service <<EOF
[Unit]
Description=CamperRouter Backend API
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/camper-router/backend
ExecStart=/usr/bin/python3 app.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

cat > /etc/systemd/system/camper-router-ui.service <<EOF
[Unit]
Description=CamperRouter Touchscreen UI
After=network.target

[Service]
Type=simple
User=root
Environment="DISPLAY=:0"
WorkingDirectory=/opt/camper-router/touchscreen
ExecStart=/usr/bin/python3 ui.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# Reload systemd
systemctl daemon-reload

# Enable services
echo "[*] Enabling services..."
systemctl enable camper-router-backend
systemctl enable camper-router-ui
systemctl enable hostapd
systemctl enable dnsmasq

# Setup iptables forwarding
echo "[*] Configuring iptables..."
echo "1" > /proc/sys/net/ipv4/ip_forward

cat > /etc/iptables/rules.v4 <<EOF
*filter
:INPUT ACCEPT [0:0]
:FORWARD ACCEPT [0:0]
:OUTPUT ACCEPT [0:0]
-A FORWARD -m state --state RELATED,ESTABLISHED -j ACCEPT
-A FORWARD -i wlan0 -o ppp0 -j ACCEPT
COMMIT
*nat
:PREROUTING ACCEPT [0:0]
:INPUT ACCEPT [0:0]
:OUTPUT ACCEPT [0:0]
:POSTROUTING ACCEPT [0:0]
-A POSTROUTING -o ppp0 -j MASQUERADE
COMMIT
EOF

iptables-restore < /etc/iptables/rules.v4

# Setup GPIO touchscreen
echo "[*] Configuring GPIO touchscreen..."
echo "dtoverlay=spi0-1cs,cs0_pin=8" >> /boot/firmware/config.txt

# Setup database
echo "[*] Initializing database..."
python3 -c "from database import init_db, get_db; init_db(None)"

echo ""
echo "=========================================="
echo "Setup complete!"
echo "=========================================="
echo ""
echo "Next steps:"
echo "1. Reboot: sudo reboot"
echo "2. Access web dashboard: http://raspberrypi.local:5000"
echo "3. Configure touchscreen via raspi-config"
echo ""
echo "Default credentials:"
echo "Password: 1234"
echo "WiFi SSID: CamperRouter"
echo "WiFi Password: password123"
echo ""
