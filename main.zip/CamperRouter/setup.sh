#!/bin/bash
# CamperRouter Setup Script for Raspberry Pi 3
set -e

echo "=========================================="
echo "CamperRouter - Setup Script"
echo "=========================================="

if [ "$EUID" -ne 0 ]; then 
  echo "Please run as root (sudo)"
  exit 1
fi

echo "[*] Updating system..."
apt update && apt upgrade -y

echo "[*] Installing dependencies..."
apt install -y \
  python3-pip \
  python3-dev \
  git \
  hostapd \
  dnsmasq \
  iptables-persistent \
  modemmanager \
  libgpiod-dev \
  nodejs \
  npm

echo "[*] Installing Python packages..."
pip3 install --break-system-packages -r requirements.txt

echo "[*] Creating directories..."
mkdir -p /var/lib/camper-router
mkdir -p /etc/camper-router
mkdir -p /opt/camper-router

echo "[*] Copying files..."
cp -r backend /opt/camper-router/
cp -r web /opt/camper-router/

echo "[*] Setting up configuration..."
cp config.json.example /etc/camper-router/config.json 2>/dev/null || true

echo "[*] Configuring hostapd..."
cat > /etc/hostapd/hostapd.conf <<EOF
interface=wlan0
driver=nl80211
ssid=CamperRouter
hw_mode=g
channel=6
wmm_enabled=1
wpa=2
wpa_passphrase=password123
wpa_key_mgmt=WPA-PSK
wpa_pairwise=CCMP
wpa_ptk_rekey=600
EOF

echo "[*] Configuring dnsmasq..."
cat > /etc/dnsmasq.conf <<EOF
interface=wlan0
dhcp-range=192.168.1.100,192.168.1.254,255.255.255.0,24h
dhcp-option=option:router,192.168.1.1
dhcp-leasefile=/var/lib/dnsmasq/dnsmasq.leases
EOF
mkdir -p /var/lib/dnsmasq

echo "[*] Installing systemd services..."
cat > /etc/systemd/system/camper-router-backend.service <<EOF
[Unit]
Description=CamperRouter Backend API
After=network.target modemmanager.service

[Service]
Type=simple
User=root
WorkingDirectory=/opt/camper-router/backend
ExecStart=/usr/bin/python3 app.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable camper-router-backend

echo "[*] Configuring iptables..."
echo "1" > /proc/sys/net/ipv4/ip_forward

cat > /etc/iptables/rules.v4 <<EOF
*filter
:INPUT ACCEPT [0:0]
:FORWARD ACCEPT [0:0]
:OUTPUT ACCEPT [0:0]
-A FORWARD -m state --state RELATED,ESTABLISHED -j ACCEPT
-A FORWARD -i wlan0 -o ppp0 -j ACCEPT
COMMIT
*nat
:PREROUTING ACCEPT [0:0]
:INPUT ACCEPT [0:0]
:OUTPUT ACCEPT [0:0]
:POSTROUTING ACCEPT [0:0]
-A POSTROUTING -o ppp0 -j MASQUERADE
COMMIT
EOF

iptables-restore < /etc/iptables/rules.v4

echo ""
echo "=========================================="
echo "Setup complete!"
echo "=========================================="
echo ""
echo "Next steps:"
echo "1. Start the backend: sudo systemctl start camper-router-backend"
echo "2. Access API: http://raspberrypi.local:5000/api/health"
echo ""
echo "Default credentials:"
echo "Password: 1234"
echo "WiFi SSID: CamperRouter"
echo "WiFi Password: password123"
echo ""
